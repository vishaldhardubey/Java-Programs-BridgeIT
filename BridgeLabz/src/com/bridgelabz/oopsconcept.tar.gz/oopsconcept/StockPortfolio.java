package com.bridgelabz.oopsconcept;

import java.util.ArrayList;

public class StockPortfolio {
	private ArrayList<Stock> arrayStock=new ArrayList<Stock>();
	
	public ArrayList<Stock> getArrayStock() {
		return arrayStock;
	}
	public void setArrayStock(ArrayList<Stock> arrayStock) {
		this.arrayStock = arrayStock;
	}
}
