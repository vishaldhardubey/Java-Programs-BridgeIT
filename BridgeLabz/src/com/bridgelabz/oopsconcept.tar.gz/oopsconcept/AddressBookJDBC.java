package com.bridgelabz.oopsconcept;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.json.simple.JSONArray;

import com.bridgelabz.utility.Utility;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class AddressBookJDBC implements AddressBookDataStorage {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";

	@Override
	public void read() {
		System.out.println("Enter the Name to create new Address Book");
		String name=Utility.scanString();
		DataSource ds=null;
		ds=getMySQLDataSource();
		Connection con=null;
		ResultSet resultSet=null;
		Statement statement=null;
		try {
			con=ds.getConnection();
			String queryCreateTable="select * from "+name;
			statement=con.createStatement();
			resultSet=statement.executeQuery(queryCreateTable);
			while(resultSet.next()) {
				String fullname=resultSet.getString("Name");
				int mobile=resultSet.getInt("MobileNumber");
				String city=resultSet.getString("City");
				String state=resultSet.getString("State");
				String zip=resultSet.getString("ZipCode");
				
				System.out.println("===============================================");
				System.out.println("Registration Number :"+fullname);
				System.out.println("Student First Name  :"+mobile);
				System.out.println("Student First Name  :"+city);
				System.out.println("Student  Email ID   :"+state);
				System.out.println("Student Mobile Num  :"+zip);
				System.out.println("===============================================");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	

	@Override
	public void doSave(JSONArray jsonArray) {
		List<A_PersonDetails> list=new ArrayList<>();
		for (int i = 0; i < list.size(); i++) {
			//add element from jsonarray to list
		}
		for (int i = 0; i < array.length; i++) {
			
			//add data from list to table
			
		System.out.println("Enter the Address Book where you want to store the Address");
		String tableName=Utility.scanString();
		DataSource ds=null;
		ds=getMySQLDataSource();
		Connection con=null;
		PreparedStatement preStatement=null;
		
			try {
				con=ds.getConnection();
				String query="insert into "+tableName+" value("+name+","+mobile+","+city+","+state+","+zip")";
				
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	public void createNewAddressBook() {
		System.out.println("Enter the Name to create new Address Book");
		String name=Utility.scanString();
		DataSource ds=null;
		ds=getMySQLDataSource();
		Connection con=null;
		PreparedStatement preStatement=null;
		try {
			con=ds.getConnection();
			System.out.println("Enter the Address Book Name");
			String addressBookName=Utility.scanString();
			System.out.println("Enter the Name");
			String name1=Utility.scanString();
			System.out.println("Enter the Mobile Number");
			int mobile=Utility.scanInt();
			System.out.println("Enter the City");
			String city=Utility.scanString();
			System.out.println("Enter the State");
			String state=Utility.scanString();
			System.out.println("Enter the ZIP Code");
			int zipCode=Utility.scanInt();
			
			String queryCreateTable="create table "+addressBookName+" values(Name varchar(50)"
					+ ", Mobile_Number bigint(10), City varchar(20),State varchar(20),ZipCode bigint(7))";
			String query="insert into FamilyAddressBook values (?,?,?,?,?)";
			preStatement = con.prepareStatement(query);
			preStatement.setString(1, name1);
			preStatement.setInt(2, mobile);
			preStatement.setString(3, city);
			preStatement.setString(4, state);
			preStatement.setInt(5,zipCode);
			preStatement.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static DataSource getMySQLDataSource() {
		Properties props = new Properties();
		FileInputStream fis = null;
		MysqlDataSource mysqlDS = null;
		try {
			fis = new FileInputStream("/home/administrator/Desktop/git_branching_demo/JDBCF/src/main/java/Properties.properties");
			props.load(fis);
			mysqlDS = new MysqlDataSource();
			mysqlDS.setURL(props.getProperty("MYSQL_DB_URL"));
			mysqlDS.setUser(props.getProperty("MYSQL_DB_USERNAME"));
			mysqlDS.setPassword(props.getProperty("MYSQL_DB_PASSWORD"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return mysqlDS;
	}


}
