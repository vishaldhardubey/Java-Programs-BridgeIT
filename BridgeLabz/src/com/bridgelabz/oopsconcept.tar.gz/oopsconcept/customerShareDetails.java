package com.bridgelabz.oopsconcept;

import java.util.ArrayList;

public class customerShareDetails {
	
	private ArrayList<CompanyShares> shareArray1=new ArrayList<CompanyShares>();

	
	public ArrayList<CompanyShares> getShareArray1() {
		return shareArray1;
	}
	public void setShareArray1(ArrayList<CompanyShares> shareArray1) {
		this.shareArray1 = shareArray1;
	}
}
