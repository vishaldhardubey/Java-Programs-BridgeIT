package com.bridgelabz.oopsconcept;

public class Stock {
	private String shareName;
	private long numOfShare;
	private long sharePrice;
	public Stock() {}
	public String getShareName() {
		return shareName;
	}
	public void setShareName(String shareName) {
		this.shareName = shareName;
	}
	public long getNumOfShare() {
		return numOfShare;
	}
	public void setNumOfShare(long numOfShare) {
		this.numOfShare = numOfShare;
	}
	public long getSharePrice() {
		return sharePrice;
	}
	public void setSharePrice(long sharePrice) {
		this.sharePrice = sharePrice;
	}
	
}
