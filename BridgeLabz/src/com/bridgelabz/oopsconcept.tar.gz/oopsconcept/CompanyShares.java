package com.bridgelabz.oopsconcept;

public class CompanyShares {
		private String shareName;
		private long numOfShare;
		private long sharePrice;
		private long DateAndTime;
		public String getShareName() {
			return shareName;
		}
		public void setShareName(String shareName) {
			this.shareName = shareName;
		}
		public long getNumOfShare() {
			return numOfShare;
		}
		public void setNumOfShare(long numOfShare) {
			this.numOfShare = numOfShare;
		}
		public long getSharePrice() {
			return sharePrice;
		}
		public void setSharePrice(long sharePrice) {
			this.sharePrice = sharePrice;
		}
		public long getDateAndTime() {
			return DateAndTime;
		}
		public void setDateAndTime(long dateAndTime) {
			DateAndTime = dateAndTime;
		}
}
