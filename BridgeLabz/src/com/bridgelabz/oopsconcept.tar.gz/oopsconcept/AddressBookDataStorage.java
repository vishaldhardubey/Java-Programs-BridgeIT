package com.bridgelabz.oopsconcept;

import org.json.simple.JSONArray;

public interface AddressBookDataStorage {
	public void read();
	void doSave(JSONArray jsonArray);
}
